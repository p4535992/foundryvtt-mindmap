import { log } from '../module/util/log.js';
// import { dagre } from '../lib/cytoscape/dagre/cytoscape-dagre.js';

export class Graph {
	static init(container, data) {
		const margin = {top: 20, right: 120, bottom: 20, left: 120},
					height =  500 - margin.top - margin.bottom,
					width =  container.clientWidth - 30 - margin.left - margin.right;
		// const svg = d3.select(container).select('.d3-tree').append('svg')
		// 		.attr('width', width + margin.right + margin.left)
		// 		.attr('height', height + margin.top + margin.bottom)
		// 	.append("g")
		// 		.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
		// cytoscape.use( dagre )
		let cy = cytoscape({
			container: container.querySelector('.d3-tree'),
			elements: [ // list of graph elements to start with
				{ // node a
					data: { id: 'qlzLDJuqK7HNb3cy', type:"JournalEntry" }
				},
				{ // node b
					data: { id: 'WquMRMWr5gTx7Qrd', type:"JournalEntry" }
				},
				{ // node b
					data: { id: 'uRAS8eO7VOolui9w', type:"JournalEntry" }
				},
				{ // edge ab
					data: { id: 'qlzLDJuqK7HNb3cy-WquMRMWr5gTx7Qrd', source: 'qlzLDJuqK7HNb3cy', target: 'WquMRMWr5gTx7Qrd' }
				},
				{ // edge ab
					data: { id: 'qlzLDJuqK7HNb3cy-uRAS8eO7VOolui9w', source: 'qlzLDJuqK7HNb3cy', target: 'uRAS8eO7VOolui9w' }
				}
			],
			style: [ // the stylesheet for the graph
				{
					selector: 'node',
					style: {
						'background-color': '#666',
						'label': 'data(id)'
					}
				},
		
				{
					selector: 'grid',
					style: {
						'width': 3,
						'line-color': '#ccc',
						'target-arrow-color': '#ccc',
						'target-arrow-shape': 'triangle'
					}
				}
			],

			layout: {
				name: 'grid',
				rows: 1
			}
		});
		log(cy.$('node').data());
		// return new D3Tree(data, svg, {height, width, margin});
	}
}

class D3Tree {
	constructor(data, svg, options = {}) {
		this.svg = svg;
		this.options = mergeObject(this.defaultOptions, options);
		const {height, width, margin } = this.options;
		this.tree = d3.tree().size([this.options.width, this.options.height]);
		this.root = d3.hierarchy(data, function(d) { return d.children; });
		this.root.x0 = height / 2;
		this.root.y0 = 0;

		this._update();
	}

	get defaultOptions() {
		return {
			width: 500,
			height: 500,
			margin: {top: 20, right: 120, bottom: 20, left: 120},
			iconSize: 50
		};
	}

	get icon() {
		return {
			"JournalEntry": "modules/graphs/assets/open-book.svg"
		};
	}

	get iconPath() {
		return {
			"JournalEntry": 'M149.688 85.625c-1.234.005-2.465.033-3.72.063-33.913.806-75.48 10.704-127.25 33.718V362.78c60.77-28.82 106.718-37.067 144.22-33.092 33.502 3.55 59.685 16.66 83.562 31.187v-242.97c-23.217-17.744-50.195-30.04-85.97-32-3.52-.192-7.142-.296-10.843-.28zm211.968 0c-3.7-.016-7.322.088-10.844.28-35.773 1.96-62.75 14.256-85.968 32v242.97c23.876-14.527 50.06-27.637 83.562-31.188 37.502-3.974 83.45 4.272 144.22 33.094V119.407c-51.77-23.014-93.337-32.912-127.25-33.72-1.255-.028-2.486-.056-3.72-.06zm5.72 261.78c-1.038-.002-2.074.017-3.095.033-4.808.075-9.43.37-13.905.843-33.932 3.597-59.603 17.976-85.53 34.44v.28c-6.554-1.99-13.02-2.37-19.408-.97-25.566-16.177-51.003-30.202-84.468-33.75-5.595-.592-11.44-.883-17.564-.842-32.04.213-71.833 9.778-124.687 35.937v42.53c60.77-28.823 106.714-37.067 144.218-33.092 18.545 1.965 34.837 6.845 49.75 13.28-4.682 6.064-9.308 13.268-13.875 21.688h117.156c-5.93-8.22-11.798-15.414-17.626-21.56 14.996-6.503 31.39-11.43 50.062-13.408 37.503-3.974 83.448 4.27 144.22 33.094v-42.53c-53.16-26.31-93.115-35.863-125.25-35.97z',
			"Actor": "M256 54.99c-27 0-46.418 14.287-57.633 32.23-10.03 16.047-14.203 34.66-15.017 50.962-30.608 15.135-64.515 30.394-91.815 45.994-14.32 8.183-26.805 16.414-36.203 25.26C45.934 218.28 39 228.24 39 239.99c0 5 2.44 9.075 5.19 12.065 2.754 2.99 6.054 5.312 9.812 7.48 7.515 4.336 16.99 7.95 27.412 11.076 15.483 4.646 32.823 8.1 47.9 9.577-14.996 25.84-34.953 49.574-52.447 72.315C56.65 378.785 39 403.99 39 431.99c0 4-.044 7.123.31 10.26.355 3.137 1.256 7.053 4.41 10.156 3.155 3.104 7.017 3.938 10.163 4.28 3.146.345 6.315.304 10.38.304h111.542c8.097 0 14.026.492 20.125-3.43 6.1-3.92 8.324-9.275 12.67-17.275l.088-.16.08-.166s9.723-19.77 21.324-39.388c5.8-9.808 12.097-19.576 17.574-26.498 2.74-3.46 5.304-6.204 7.15-7.754.564-.472.82-.56 1.184-.76.363.2.62.288 1.184.76 1.846 1.55 4.41 4.294 7.15 7.754 5.477 6.922 11.774 16.69 17.574 26.498 11.6 19.618 21.324 39.387 21.324 39.387l.08.165.088.16c4.346 8 6.55 13.323 12.61 17.254 6.058 3.93 11.974 3.45 19.957 3.45H448c4 0 7.12.043 10.244-.304 3.123-.347 6.998-1.21 10.12-4.332 3.12-3.122 3.984-6.997 4.33-10.12.348-3.122.306-6.244.306-10.244 0-28-17.65-53.205-37.867-79.488-17.493-22.74-37.45-46.474-52.447-72.315 15.077-1.478 32.417-4.93 47.9-9.576 10.422-3.125 19.897-6.74 27.412-11.075 3.758-2.168 7.058-4.49 9.81-7.48 2.753-2.99 5.192-7.065 5.192-12.065 0-11.75-6.934-21.71-16.332-30.554-9.398-8.846-21.883-17.077-36.203-25.26-27.3-15.6-61.207-30.86-91.815-45.994-.814-16.3-4.988-34.915-15.017-50.96C302.418 69.276 283 54.99 256 54.99z",
			"Item": "M208 95c-3.583 0-7.736 1.925-9.977 4.613-2.24 2.69-2.99 5.447-3.4 7.907-.82 4.92-.247 9.48.5 13.96.316 1.897.698 3.748 1.096 5.52h18.534c-.67-2.54-1.387-5.542-1.877-8.48-.35-2.093-.483-3.963-.53-5.52h87.305c-.046 1.557-.18 3.427-.53 5.52-.49 2.938-1.205 5.94-1.876 8.48h18.535c.4-1.772.78-3.623 1.097-5.52.747-4.48 1.32-9.04.5-13.96-.41-2.46-1.16-5.218-3.4-7.907C311.737 96.925 307.583 95 304 95h-96zm-105 16v18h50v-18h-50zm256 0v18h50v-18h-50zM96 145c-5 0-11.05 2.777-15.637 7.363C75.777 156.95 73 163 73 168v208c0 5 2.777 11.05 7.363 15.637C84.95 396.223 91 399 96 399h23V145H96zm41 0v254h238V145H137zm256 0v254h23c5 0 11.05-2.777 15.637-7.363C436.223 387.05 439 381 439 376V168c0-5-2.777-11.05-7.363-15.637C427.05 147.777 421 145 416 145h-23z",
			"RollTable": "M208 95c-3.583 0-7.736 1.925-9.977 4.613-2.24 2.69-2.99 5.447-3.4 7.907-.82 4.92-.247 9.48.5 13.96.316 1.897.698 3.748 1.096 5.52h18.534c-.67-2.54-1.387-5.542-1.877-8.48-.35-2.093-.483-3.963-.53-5.52h87.305c-.046 1.557-.18 3.427-.53 5.52-.49 2.938-1.205 5.94-1.876 8.48h18.535c.4-1.772.78-3.623 1.097-5.52.747-4.48 1.32-9.04.5-13.96-.41-2.46-1.16-5.218-3.4-7.907C311.737 96.925 307.583 95 304 95h-96zm-105 16v18h50v-18h-50zm256 0v18h50v-18h-50zM96 145c-5 0-11.05 2.777-15.637 7.363C75.777 156.95 73 163 73 168v208c0 5 2.777 11.05 7.363 15.637C84.95 396.223 91 399 96 399h23V145H96zm41 0v254h238V145H137zm256 0v254h23c5 0 11.05-2.777 15.637-7.363C436.223 387.05 439 381 439 376V168c0-5-2.777-11.05-7.363-15.637C427.05 147.777 421 145 416 145h-23z"
		}
	}

	async _update(source = this.root) {
		const duration = 500;
		const 
					treeData = this.tree(this.root),
					nodes = treeData.descendants(),
      		links = treeData.descendants().slice(1),
					svg = this.svg;
		console.debug(treeData, this.tree);
		var i = 0;
		// Normalize for fixed-depth.
		for (var node of nodes) {
			node.y = node.depth * 180;
			node.data.name = (await fromUuid(node.data.type + '.' + node.data.id)).data.name;
		}
	
		// ****************** Nodes section ***************************
	
		// Update the nodes...
		var node = svg.selectAll('g.node')
				.data(nodes, function(d) {return d.id || (d.id = ++i); });
	
		// Enter any new modes at the parent's previous position.
		var nodeEnter = node.enter().append('g')
				.attr('class', 'node')
				.attr("transform", function(d) {
					return "translate(" + source.y0 + "," + source.x0 + ")";
				})
				.on('click', (...args) => this._onClick(...args) )
				.on('contextmenu', (...args) => this._onContext(...args))
	
		nodeEnter
				.append('path')
				.attr('viewBox', '0 0 512 512')
				.attr('d', (d) => this.iconPath[d.data.type])
				.attr('transform', 'scale(0.08)translate(-256,-256)')
				.attr('class', 'node')
	
		// Add labels for the nodes
		nodeEnter.append('text')
				.attr("dy", "25px")
				.attr('text-anchor', 'middle')
				.text(function(d) { return d.data.name; });
	
		// UPDATE
		var nodeUpdate = nodeEnter.merge(node);
	
		// Transition to the proper position for the node
		nodeUpdate.transition()
			.duration(duration)
			.attr("transform", function(d) { 
					return "translate(" + d.y + "," + d.x + ")";
				});
	
		// Remove any exiting nodes
		var nodeExit = node.exit().transition()
				.duration(duration)
				.attr("transform", function(d) {
						return "translate(" + source.y + "," + source.x + ")";
				})
				.remove();
	
		// On exit reduce the node circles size to 0
		nodeExit.select('path')
			.attr('transform', 'scale(1e-6)translate(-256,-256)');
	
		// On exit reduce the opacity of text labels
		nodeExit.select('text')
			.style('fill-opacity', 1e-6);
	
		// ****************** links section ***************************
	
		// Update the links...
		var link = svg.selectAll('path.link')
				.data(links, function(d) { return d.id; });
	
		// Enter any new links at the parent's previous position.
		var linkEnter = link.enter().insert('path', "g")
				.attr("class", "link")
				.attr('d', function(d){
					var o = {x: source.x0, y: source.y0}
					return diagonal(o, o)
				});
	
		// UPDATE
		var linkUpdate = linkEnter.merge(link);
	
		// Transition back to the parent element position
		linkUpdate.transition()
				.duration(duration)
				.attr('d', function(d){ return diagonal(d, d.parent) });
	
		// Remove any exiting links
		var linkExit = link.exit().transition()
				.duration(duration)
				.attr('d', function(d) {
					var o = {x: source.x, y: source.y}
					return diagonal(o, o)
				})
				.remove();
	
		// Store the old positions for transition.
		nodes.forEach(function(d){
			d.x0 = d.x;
			d.y0 = d.y;
		});
	}


	// Toggle children on click.
	async _onClick(d) {
		const entity = await fromUuid([d.data.type, d.data.id].join("."));
		entity.sheet.render(true);
	}

	async _onContext(d) {
		if (d.children) {
			d._children = d.children;
			d.children = null;
		} else {
			d.children = d._children;
			d._children = null;
		}
		this._update(d);
	}
}

function diagonal(s, d) {

	let path = `M ${s.y} ${s.x}
					C ${(s.y + d.y) / 2} ${s.x},
						${(s.y + d.y) / 2} ${d.x},
						${d.y} ${d.x}`

	return path
}
