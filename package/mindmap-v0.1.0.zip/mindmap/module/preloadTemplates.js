export const preloadTemplates = async function() {
	const templatePaths = [
		// Add paths to "modules/graphs/templates"
	];

	return loadTemplates(templatePaths);
}
