import { warn } from "../foundryvtt-mindmap.js";
export let readyHooks = async () => {
};
export let initHooks = () => {
    warn("Init Hooks processing");
    // setup all the hooks
};
